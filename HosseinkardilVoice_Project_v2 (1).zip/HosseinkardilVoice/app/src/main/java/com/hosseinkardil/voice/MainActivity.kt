package com.hosseinkardil.voice

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.view.Gravity
import android.view.WindowManager
import android.view.ViewGroup
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private val running = AtomicBoolean(false)
    @Volatile private var gain = 1.6f
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    private var aec: AcousticEchoCanceler? = null
    private lateinit var status: TextView
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        val heading = TextView(this).apply {
            text = "HOSSEINKARDIL\nتقویت و پاک‌سازی صدا"
            textSize = 23f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "وضعیت: آماده"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 18)
        }
        val gainLabel = TextView(this).apply { text = "قدرت صدا: ۱۶۰٪"; textSize = 16f }
        val gainBar = SeekBar(this).apply {
            max = 300
            progress = 160
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    gain = (progress.coerceAtLeast(50) / 100f)
                    gainLabel.text = "قدرت صدا: ${progress.coerceAtLeast(50)}٪"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        startButton = Button(this).apply {
            text = "شروع شنود و تقویت زنده"
            setOnClickListener { if (running.get()) stopAudio() else requestAndStart() }
        }
        val note = TextView(this).apply {
            text = "نکته: این نسخه صدای تقویت‌شده را از خروجی گوشی/هدفون پخش می‌کند. اندروید بدون روت اجازه نمی‌دهد برنامه صدای میکروفون را مستقیماً جایگزین میکروفون شاد یا سایر برنامه‌ها کند. برای جلوگیری از سوت و فیدبک، از هدفون استفاده کن."
            textSize = 14f
            setPadding(0, 22, 0, 0)
        }
        root.addView(heading, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(status)
        root.addView(gainLabel)
        root.addView(gainBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(startButton)
        root.addView(note)
        setContentView(root)
    }

    private fun requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        } else startAudio()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else Toast.makeText(this, "مجوز میکروفون لازم است", Toast.LENGTH_LONG).show()
    }

    private fun startAudio() {
        if (running.get()) return
        val sampleRate = 44100
        val inputMin = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val outputMin = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (inputMin <= 0 || outputMin <= 0) {
            status.text = "وضعیت: دستگاه از این تنظیمات صوتی پشتیبانی نمی‌کند"
            return
        }
        try {
            val bufferSize = maxOf(inputMin, outputMin, 4096)
            val input = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
            val output = AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize,
                AudioTrack.MODE_STREAM)
            if (input.state != AudioRecord.STATE_INITIALIZED || output.state != AudioTrack.STATE_INITIALIZED) {
                input.release(); output.release()
                status.text = "وضعیت: راه‌اندازی صدا ناموفق بود"
                return
            }
            recorder = input
            player = output
            ns = if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(input.audioSessionId) else null
            agc = if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(input.audioSessionId) else null
            aec = if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(input.audioSessionId) else null
            ns?.enabled = true
            agc?.enabled = true
            aec?.enabled = true
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isSpeakerphoneOn = false
            input.startRecording()
            output.play()
            running.set(true)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            startButton.text = "توقف"
            status.text = "وضعیت: در حال پردازش زنده"
            thread(name = "LiveVoiceProcessor") {
                val data = ShortArray(bufferSize / 2)
                while (running.get()) {
                    val count = input.read(data, 0, data.size)
                    if (count > 0) {
                        val currentGain = gain
                        for (i in 0 until count) data[i] = (data[i] * currentGain).roundToInt().coerceIn(-32768, 32767).toShort()
                        output.write(data, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            stopAudio()
            status.text = "وضعیت: خطا در شروع میکروفون"
            Toast.makeText(this, e.message ?: "خطای صوتی", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAudio() {
        running.set(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release()
        recorder = null; player = null
        ns?.release(); agc?.release(); aec?.release()
        ns = null; agc = null; aec = null
        (getSystemService(AUDIO_SERVICE) as AudioManager).mode = AudioManager.MODE_NORMAL
        if (::startButton.isInitialized) startButton.text = "شروع شنود و تقویت زنده"
        if (::status.isInitialized) status.text = "وضعیت: متوقف"
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }
}
